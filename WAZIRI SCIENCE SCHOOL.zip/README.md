# Waziri Science School

Welcome to the Waziri Science School repository! This project contains the source code for our school website.

## Files
- `index.html` - Main HTML structure
- `style.css` - Website styling
- `script.js` - Interactive JavaScript features